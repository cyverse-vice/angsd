void bam_likes_init();
void call_bam(chunkyT *chk,double **likes,int trim,int *keepSites);
void bam_likes_destroy();

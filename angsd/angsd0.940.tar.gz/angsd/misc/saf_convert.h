int main_text2safv4(int argc,char **argv);

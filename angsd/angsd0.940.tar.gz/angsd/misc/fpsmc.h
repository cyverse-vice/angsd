int psmc_wrapper(args *pars,int block);
